<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">


            


            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Available qty</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($p->id); ?></th>
                        <td><?php echo e($p->p_name); ?></td>
                        <td><?php echo e($p->p_qty); ?></td>
                        <td><?php echo e($p->p_price); ?></td>
                        <td><button class="btn btn-primary">buy now</button></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
                
                </tbody>
              </table>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Madhushanka\Documents\Laravel projects\payhere-app\resources\views/home.blade.php ENDPATH**/ ?>