@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">


            


            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Available qty</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>

                    @foreach ($products as $p)
                    <tr>
                        <th scope="row">{{  $p->id }}</th>
                        <td>{{  $p->p_name }}</td>
                        <td>{{  $p->p_qty }}</td>
                        <td>{{  $p->p_price }}</td>
                        <td><button class="btn btn-primary">buy now</button></td>
                      </tr>
                    @endforeach
     
                
                </tbody>
              </table>

        </div>
    </div>
</div>
@endsection
